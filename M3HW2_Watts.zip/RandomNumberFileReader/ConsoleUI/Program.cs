﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleUI
{
    class Program
    {
        /* Jesse Watts
         * CSC 253
         * 28 Sep 2019
         * Takes the random number write file & reads it.
         */
        static void Main(string[] args)
        {
            try
            {
                int number;
                StreamReader inputFile;

                inputFile = File.OpenText("randomNumber.txt");
                while (!inputFile.EndOfStream)
                {
                    // Get random number.
                   number = int.Parse(inputFile.ReadLine($"The random number choosen is {number}."));
                    Console.ReadLine();
                }
                inputFile.Close();
            }
            catch
            {
                // Display error message.
                Console.WriteLine("Unable to open file!");
            }
        }
    }
}

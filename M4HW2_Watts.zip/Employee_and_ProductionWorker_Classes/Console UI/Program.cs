﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobPositionsLibrary;

namespace ConsoleUI
{
    /*Jesse Watts
     * CSC 253
     * 27 Oct 2019
     * Create classes for employee & production worker & place them
     * in a class library to be used to display information.
     */
    class Program
    {

        static void Main(string[] args)
        {
            JobPositionsLibrary.Employee myEmployee = new JobPositionsLibrary.Employee("Jesse", "0001");

            JobPositionsLibrary.ProductionWorker myWorker = new JobPositionsLibrary.ProductionWorker("Jesse", "0001", 1, 22);

            JobPositionsLibrary.ShiftSupervisor mySuper = new JobPositionsLibrary.ShiftSupervisor("Morgan", "0002", 1, 60000, 3000);

            /*Create a list using the parent class Employee.*/
            List<JobPositionsLibrary.Employee> mylist = new List<JobPositionsLibrary.Employee>();

            /*Create a list using the child class ProductionWorker.*/
            List<JobPositionsLibrary.ProductionWorker> myList = new List<JobPositionsLibrary.ProductionWorker>();

            /*Create a list using the child class ShiftSupervisor*/
            List<JobPositionsLibrary.ShiftSupervisor> Mylist = new List<JobPositionsLibrary.ShiftSupervisor>();

            mylist.Add(myEmployee);           

            foreach (JobPositionsLibrary.Employee working in mylist)
            {
                /*The commented out section allows for the user to enter
                the information & for it to be displayed.*/

                //string theEmployee;
                //int employeeNumber;

                //Console.Write("What is the employee's name? => ");
                //theEmployee = Console.ReadLine();
                //Console.Write("What is his/her employee number? => ");
                //employeeNumber = int.Parse (Console.ReadLine());
                //Console.WriteLine($"The employee's name is {theEmployee} & employee number is {employeeNumber}.");
                Console.WriteLine($"The employee's name is {working.Name} & employee number is {working.EmployeeNumber}.");
                Console.WriteLine();
            }

            myList.Add(myWorker);

            foreach (JobPositionsLibrary.ProductionWorker working in myList)
            {
                Console.WriteLine($"The employee's shift is {working.Shift} & the pay rate is " +
                    $"{working.HourlyPay.ToString("C")} an hour.");
                Console.WriteLine();
            }

            Mylist.Add(mySuper);

            foreach (JobPositionsLibrary.ShiftSupervisor working in Mylist)
            {
                Console.WriteLine($"The supervisor's name is {working.Name} & works {working.Shift} shift. " +
                    $"{working.Name} receives an annual salary of {working.AnnualSalary.ToString("C")} with a bonus of " +
                    $"{working.ProBonus.ToString("C")}.");
            }
            
            Console.ReadLine();
        }        
    }
    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobPositionsLibrary
{
    public class ShiftSupervisor : Employee
    {
        public ShiftSupervisor(string name, string employeeNumber, int shift, decimal annualSalary, decimal proBonus) : 
                                                                                           base(name, employeeNumber)
        {
            AnnualSalary = annualSalary;
            ProBonus = proBonus;
            Shift = shift;
        }

        public decimal AnnualSalary { get; set; }
        public decimal ProBonus { get; set; }
        public int Shift { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Positions
{
    //This is the child class.  It has inherited the parameters from the parent
    //class Employee.
    public class ProductionWorker : Employee
    {
        public ProductionWorker(string name, string employeeNumber, int shift, decimal hourlyPay) : base(name, employeeNumber)
        {
            Shift = shift;
            HourlyPay = hourlyPay;
        }

        public int Shift { get; set; }
        public decimal HourlyPay { get; set; }
    }
}

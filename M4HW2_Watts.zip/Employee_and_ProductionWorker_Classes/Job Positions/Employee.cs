﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Positions
{
    //This is the parent class.
    public class Employee
    {
        public Employee(string name, string employeeNumber)
        {
            Name = name;
            EmployeeNumber = employeeNumber;
        }

        public string Name { get; set; }
        public string EmployeeNumber { get; set; }
    }
}

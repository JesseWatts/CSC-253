﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{/*
    Jesse Watts
    CSC 253
    2 Dec 2019
    Program takes a run-on sentence & separates it only captializing 
    the first letter in the first word.
    pg 537 - Word separator
*/
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;


            //Get input from the user to tokenize.
            Console.Write("Enter a run-on sentence: => ");
            string userInput = Console.ReadLine();

            //Create a delimiter
            //What would be the delimiter for uppercase?
            char[] delim = { };

            //Get the tokens from the string.
            string[] tokens = userInput.Split(delim);

            //Display each token.
            foreach (string s in tokens)
            {

                Console.Write(s);
            }
            Console.ReadLine();

        }
    }
}

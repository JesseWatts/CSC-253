# Streets_Of_Malice

//Easiest way to list our updates, List date and update below line 11. Initial left next to the update.


Creation date: August 30th, 2019
Current Build: S3019
Readme Edit Date: September 30th, 2019


Below Contains a list of changes and updates to the program:

August 30th, 2019
Created intial program

September 30th, 2019 
RC>Created Commands, Map, Options, Program, Standard Messages Classes
RC>Reogranized code from program class into classes above.

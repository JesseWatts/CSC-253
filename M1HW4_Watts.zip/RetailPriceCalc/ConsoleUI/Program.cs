﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal itemWholeSale = 0;
            decimal itemMarkUpPercent = 0;
            decimal itemRetailPrice = itemWholeSale * itemMarkUpPercent;

            Console.Write("How much does the item cost? => ");
            Console.ReadLine();

            Console.Write("What is the mark up percent? => ");
            Console.ReadLine();

            Console.Write($"The retail price of the item")
        }
    }
}

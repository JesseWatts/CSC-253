﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {/* Jesse Watts
        CSC 253
        26 Sept 2019
        The program writes random numbers to a file & the user specifies how many random
        numbers the file will hold.
    */
        static void Main(string[] args)
        {
            // Declare int variable.
            int number;
            
           // Create a Random object.
           Random rand = new Random();

           number = rand.Next(100) + 1;

            // Display the random number.
            Console.Write($"The random number choosen is {number}.");
            Console.ReadLine();

        }
    }
}

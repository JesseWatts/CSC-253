﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{/* Jesse Watts
    CSC 253
    22 Sep 2019
    Program counts & displays the most frequent character.
    */
    class Program
    {
        static void Main(string[] args)
        {
            string userInput = "";
            Console.WriteLine("Enter a sentence or phrase.");
            Console.ReadLine();
            Console.Write($"The most frequently repeated character in your sentence is => {mostRepeated(userInput)}.");
            Console.ReadLine();
        }
        static Char mostRepeated(userInput s)
        {
            int[] count = new int[256];
            int max = 0;
            char result = char.MinValue;

            Array.Clear(count, 0, count.Length - 1);

            foreach (char c in s)

                if (++count[c] > max)
                {
                    max = count[c];
                    result = c;
                    return result;
                }
        }   
    }
                
}
        
        
    

